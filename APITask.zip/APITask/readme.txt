the command used to run the scripts from windows cmd
.\shellScripts.bat postman password

